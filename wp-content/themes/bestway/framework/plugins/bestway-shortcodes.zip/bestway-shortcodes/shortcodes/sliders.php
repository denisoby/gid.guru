<?php
function mom_feature_slider($atts, $content = null) {

    extract(shortcode_atts(array(
    'type' => 'grid', // grid, mix, full
    'display' => '', //latest posts,  category, tag, posts
    'category' => '', // list with current categories
    'slides_hint' => 'yes',
    'tag' => '', // tag slug or id 
    'specific_posts' => '', // 1,5,7
    'format' => '', // video, audio, gallery
    'exclude_categories' => '', // 1,5,7
    'orderby' => 'date', // recent, popular, random
    'sort' => 'DESC', //DESC & ASC
    'count' => 10,
    'post_type' => '',
    'class' => '',

    ), $atts));
    if ($type == 'none') return;
ob_start();
$detect = new Mobile_Detect;

    //orderby 
    if ($orderby == 'popular') {
        $orderby = 'comment_count'; 
    } elseif ($orderby == 'random') {
        $orderby = 'rand';
    } else {
        $orderby = $orderby;
    }
    if ($exclude_categories != '') {
        $exclude_categories = explode(',', $exclude_categories);
    }
    if ($specific_posts != '') {
        $specific_posts = explode(',', $specific_posts);
    }
    $i = 1; 
    if (isset($_GET['slides_hint'])) {
        $slides_hint = $_GET['slides_hint'];
    }
    if ($slides_hint != 'yes')
    {
        $slides_hint = 'feature_slider_style';
    } else {
        $slides_hint = '';
    }

        if ($display == 'category') {
            $args = array(
            'ignore_sticky_posts' => 1,
            'posts_per_page' => $count, 'post_type' => $post_type, 'category__not_in' => $exclude_categories, 'cache_results' => false, 'no_found_rows' => true, 
            'cat' => $category,
            'orderby' => $orderby,
            'order' => $sort,
            'tax_query' => $format,
            ); 
        if (!is_numeric($category)) {$args['category_name'] = $category;}
        } elseif ($display == 'tag') {
            $args = array(
            'ignore_sticky_posts' => 1,
            'posts_per_page' => $count, 'post_type' => $post_type, 'category__not_in' => $exclude_categories, 'cache_results' => false, 'no_found_rows' => true, 
            'tag_id' => $tag,
            'orderby' => $orderby,
            'order' => $sort,
            'tax_query' => $format,
            ); 
            if (!is_numeric($tag)) {$args['tag'] = $tag;}
        } elseif ($display == 'posts') {
            $args = array(
            'ignore_sticky_posts' => 1,
            'posts_per_page' => $count, 'post_type' => $post_type, 'category__not_in' => $exclude_categories, 'cache_results' => false, 'no_found_rows' => true, 
            'orderby' => 'post__in',
            'order' => $sort,
            'tax_query' => $format,
            'post__in' => $specific_posts
            ); 
        } else {
            $args = array(
                'ignore_sticky_posts' => 1,
                'posts_per_page' => $count, 'post_type' => $post_type, 'category__not_in' => $exclude_categories, 'cache_results' => false, 'no_found_rows' => true,
                'orderby' => $orderby,
                'order' => $sort,
                'tax_query' => $format,
                ); 
        }

        $query = new WP_Query( $args );

?>
<?php if( $detect->isMobile() && !$detect->isTablet() ){  ?>
<div class="inner <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider s_default clearfix mobile_feature_slider">
<div class="feature_wrap default-slider-wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $image_size = 'large';
    ?>
        <div class="default_item">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%1 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } else { ?>
<?php if ($type == 'mix') { ?>

<div class="inner feature_slider_class <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider feature_slider_mix clearfix">
<div class="feature_wrap" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        $i = 1; 
        $args = array(
            'posts_per_page' => $count,
            );
        $query = new WP_Query( $args );
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $h = 'h1';
            $w = 'w1';
            $image_size = 'feature_slider_small';
            if ( $i%3 == 1 ) {
                $h = 'h2';
                $w = 'w2';
                $image_size = 'feature_slider_big';
            }
    ?>
        <div class="mom-column <?php echo esc_attr($h) ?> <?php echo esc_attr($w); ?>">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <span class="sp_date"><?php echo mom_date_format(); ?></span>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%3 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>

<?php } elseif ($type == 'full') {  ?>

<div class="feature_slider_full clearfix <?php echo esc_attr($slides_hint); ?>">
<div class="feature_wrap_full" data-count="<?php echo esc_attr($count); ?>">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
    ?>
    <?php if ( has_post_thumbnail() ) { ?>
    <div class="slider_item">
        <?php if(mom_post_image() != false) {
            mom_post_image_full('post_large_image'); 
    } ?>
        <div class="caption">
            <div class="sp_details">
            <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
            <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php echo the_title(); ?></a></h3>
            </div>
        </div> <!--End Caption-->
    </div>
    <?php } ?>
    <?php endwhile; ?>
    <?php endif; ?>
</div> <!--End Feature wrap-->
</div>
<?php } elseif ($type == 'grid2') {  ?>
<div class="inner feature_slider_class <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider_grid feature_slider_grid2 clearfix">
<div class="feature_grid_wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $h = 'h1';
            $w = 'w1';
            $image_size = 'feature_slider_square';
    ?>
        <div class="mom-column <?php echo esc_attr($h) ?> <?php echo esc_attr($w); ?>">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <span class="sp_date"><?php echo mom_date_format(); ?></span>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%6 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } elseif ($type == 'grid3') {  ?>
<div class="inner feature_slider_class <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider_grid feature_slider_grid3 clearfix">
<div class="feature_grid_wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $h = 'h2';
            $w = 'w2';
            $image_size = 'grid_slider_image';
    ?>
        <div class="mom-column <?php echo esc_attr($h) ?> <?php echo esc_attr($w); ?>">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <span class="sp_date"><?php echo mom_date_format(); ?></span>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%4 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } elseif ($type == 'default') {  ?>
<div class="inner feature_slider_class <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider s_default clearfix">
<div class="feature_wrap default-slider-wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $image_size = 'large';
    ?>
        <div class="default_item">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <span class="sp_date"><?php echo mom_date_format(); ?></span>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%1 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } else { ?>
<div class="inner feature_slider_class <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider_grid clearfix">
<div class="feature_grid_wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $h = 'h1';
            $w = 'w1';
            $image_size = 'feature_slider_square';
            if ( $i%5 == 1 || $i%5 == 2) {
                $h = 'h2';
                $w = 'w2';
                $image_size = 'grid_slider_image';
            }
    ?>
        <div class="mom-column <?php echo esc_attr($h) ?> <?php echo esc_attr($w); ?>">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <span class="sp_cate"><?php $category = get_the_category(); 
if($category[0]){
echo '<a href="'.get_category_link($category[0]->term_id ).'">'.$category[0]->cat_name.'</a>';
} ?></span>
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                    <span class="sp_date"><?php echo mom_date_format(); ?></span>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%5 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } ?>
<div class="inner responsive_feature_slider <?php echo esc_attr($slides_hint); ?>">
<div class="feature_slider s_default clearfix mobile_feature_slider">
<div class="feature_wrap default-slider-wrap <?php echo esc_attr($class); ?>" data-count="<?php echo esc_attr($count); ?>">
<div class="slider_item">
    <?php 
        if ( $query->have_posts() ) : while ( $query->have_posts() ) : $query->the_post(); 
            if (mom_post_image() != false) {
            $image_size = 'large';
    ?>
        <div class="default_item">
            <a href="<?php the_permalink(); ?>"><?php mom_post_image_full($image_size); ?></a>
            <div class="caption">
                <div class="sp_details">
                    <h3 class="sp_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
                </div>
            </div> <!--End Caption-->
        </div>
    <?php if ($i%1 == 0) { ?></div><div class="slider_item"><?php } ?>
<?php $i++; } endwhile; else : ?>
<?php endif; wp_reset_postdata(); ?>    
</div> <!-- slider item -->
</div> <!--End Feature wrap-->
</div>
</div>
<?php } //end if is mobile ?>
<?php 
    $output = ob_get_contents();
    ob_end_clean();

    return $output;
}

add_shortcode('feature_slider', 'mom_feature_slider'); 