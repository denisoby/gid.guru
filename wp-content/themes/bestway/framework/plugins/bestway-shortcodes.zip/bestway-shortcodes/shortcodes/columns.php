<?php

function mom_one_third( $atts, $content = null ) {
   return '<div class="one_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_third', 'mom_one_third');

function mom_one_third_last( $atts, $content = null ) {
   return '<div class="one_third last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('one_third_last', 'mom_one_third_last');

function mom_two_third( $atts, $content = null ) {
   return '<div class="two_third">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_third', 'mom_two_third');

function mom_two_third_last( $atts, $content = null ) {
   return '<div class="two_third last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('two_third_last', 'mom_two_third_last');

function mom_one_half( $atts, $content = null ) {
   return '<div class="one_half">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_half', 'mom_one_half');

function mom_one_half_last( $atts, $content = null ) {
   return '<div class="one_half last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('one_half_last', 'mom_one_half_last');

function mom_one_fourth( $atts, $content = null ) {
   return '<div class="one_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fourth', 'mom_one_fourth');

function mom_one_fourth_last( $atts, $content = null ) {
   return '<div class="one_fourth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('one_fourth_last', 'mom_one_fourth_last');

function mom_two_fourth( $atts, $content = null ) {
   return '<div class="two_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_fourth', 'mom_two_fourth');

function mom_two_fourth_last( $atts, $content = null ) {
   return '<div class="two_fourth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('two_fourth_last', 'mom_two_fourth_last');



function mom_three_fourth( $atts, $content = null ) {
   return '<div class="three_fourth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fourth', 'mom_three_fourth');

function mom_three_fourth_last( $atts, $content = null ) {
   return '<div class="three_fourth_last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('three_fourth_last', 'mom_three_fourth_last');

function mom_one_fifth( $atts, $content = null ) {
   return '<div class="one_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_fifth', 'mom_one_fifth');

function mom_one_fifth_last( $atts, $content = null ) {
   return '<div class="one_fifth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('one_fifth_last', 'mom_one_fifth_last');

function mom_two_fifth( $atts, $content = null ) {
   return '<div class="two_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_fifth', 'mom_two_fifth');

function mom_two_fifth_last( $atts, $content = null ) {
   return '<div class="two_fifth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('two_fifth_last', 'mom_two_fifth_last');

function mom_three_fifth( $atts, $content = null ) {
   return '<div class="three_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_fifth', 'mom_three_fifth');

function mom_three_fifth_last( $atts, $content = null ) {
   return '<div class="three_fifth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('three_fifth_last', 'mom_three_fifth_last');

function mom_four_fifth( $atts, $content = null ) {
   return '<div class="four_fifth">' . do_shortcode($content) . '</div>';
}
add_shortcode('four_fifth', 'mom_four_fifth');

function mom_four_fifth_last( $atts, $content = null ) {
   return '<div class="four_fifth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('four_fifth_last', 'mom_four_fifth_last');

function mom_one_sixth( $atts, $content = null ) {
   return '<div class="one_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('one_sixth', 'mom_one_sixth');


function mom_one_sixth_last( $atts, $content = null ) {
   return '<div class="one_sixth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('one_sixth_last', 'mom_one_sixth_last');

function mom_two_sixth( $atts, $content = null ) {
   return '<div class="two_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('two_sixth', 'mom_two_sixth');


function mom_two_sixth_last( $atts, $content = null ) {
   return '<div class="two_sixth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('two_sixth_last', 'mom_two_sixth_last');

function mom_three_sixth( $atts, $content = null ) {
   return '<div class="three_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('three_sixth', 'mom_three_sixth');


function mom_three_sixth_last( $atts, $content = null ) {
   return '<div class="three_sixth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('three_sixth_last', 'mom_three_sixth_last');

function mom_four_sixth( $atts, $content = null ) {
   return '<div class="four_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('four_sixth', 'mom_four_sixth');


function mom_four_sixth_last( $atts, $content = null ) {
   return '<div class="four_sixth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('four_sixth_last', 'mom_four_sixth_last');

function mom_five_sixth( $atts, $content = null ) {
   return '<div class="five_sixth">' . do_shortcode($content) . '</div>';
}
add_shortcode('five_sixth', 'mom_five_sixth');

function mom_five_sixth_last( $atts, $content = null ) {
   return '<div class="five_sixth last">' . do_shortcode($content) . '</div><div class="clearboth"></div>';
}
add_shortcode('five_sixth_last', 'mom_five_sixth_last');