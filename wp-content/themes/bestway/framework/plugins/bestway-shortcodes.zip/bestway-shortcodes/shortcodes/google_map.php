<?php
// Thanks to : http://www.9bitstudios.com/2013/09/create-a-google-maps-shortcode-in-wordpress/
function mom_google_map($atts, $content=null) {
	extract(shortcode_atts(array(
    'height' => '440px',
    'width' => '', //container width, full
    'lat'  => '',
    'long' => '',
    'color' => '',
    'zoom' => '13',
    'pan' => 'false',
    'controls' => 'false',
    'marker_icon' => '', //custom marker image
    'marker_title' => '',
    'marker_animation' => 'DROP',// DROP, BOUNCE
    'marker_info' => '', // temporary stopped
    'class' => ''
    
    ), $atts));
    ob_start();
    $rndn = rand(1, 1000);
    $map_id = 'mom_google_map_'.$rndn;
    if ($color != '') {
	$sat = -30;
    } else {
	$sat = 0;
    }

    $marker_animation = strtoupper($marker_animation);
    wp_enqueue_script('googlemaps');
?>
<div id="<?php echo esc_attr($map_id); ?>" class="mom_google_map google-maps <?php echo esc_attr($width); ?> <?php echo esc_attr($class); ?>" style="height: <?php echo esc_attr($height); ?>;" data-lat="<?php echo esc_attr($lat); ?>" data-long="<?php echo esc_attr($long); ?>" data-color="<?php echo esc_attr($color); ?>" data-zoom="<?php echo esc_attr($zoom); ?>" data-pan="<?php echo esc_attr($pan); ?>" data-controls="<?php echo esc_attr($controls); ?>" data-marker_icon="<?php echo esc_attr($marker_icon); ?>" data-marker_title="<?php echo esc_attr($marker_title); ?>" data-marker_animation="<?php echo esc_attr($marker_animation); ?>" data-sat="<?php echo esc_attr($sat); ?>" data-marker_info="<?php echo esc_attr($marker_info); ?>"></div>
<?php
	$output = ob_get_contents();
	ob_end_clean();
	return $output;
}
add_shortcode('map', 'mom_google_map');
