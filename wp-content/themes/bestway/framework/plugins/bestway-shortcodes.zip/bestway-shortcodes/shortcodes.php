<?php
/*
Plugin Name: Bestway Shortcodes
Plugin URI: http://themelions.com/
Description: Best way theme custom shortcodes.
Author: themelions Team
Version: 1.0
Author URI: http://themelions.com/
*/
function tl_mom_shortcodes_plugin () {
	return;
}
foreach ( glob( plugin_dir_path( __FILE__ ) . "shortcodes/*.php" ) as $file ) {
    include_once $file;
}